﻿using GenericScale;

// Example Usage
Console.WriteLine(new EqualityScale<int>(5, 5).AreEqual());
Console.WriteLine(new EqualityScale<string>("test", "example").AreEqual());