﻿// ReSharper disable CheckNamespace
namespace CarManufacturer;

public class StartUp
{
    public static void Main()
    {
        List<Tire[]> tiresList = new();

        string command = Console.ReadLine()!;
        while (command != "No more tires")
        {
            string[] tireInfo = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);

            int tire1Year = int.Parse(tireInfo[0]);
            double tire1Pressure = double.Parse(tireInfo[1]);
            int tire2Year = int.Parse(tireInfo[2]);
            double tire2Pressure = double.Parse(tireInfo[3]);
            int tire3Year = int.Parse(tireInfo[4]);
            double tire3Pressure = double.Parse(tireInfo[5]);
            int tire4Year = int.Parse(tireInfo[6]);
            double tire4Pressure = double.Parse(tireInfo[7]);

            Tire tireOne = new Tire(tire1Year, tire1Pressure);
            Tire tireTwo = new Tire(tire2Year, tire2Pressure);
            Tire tireThree = new Tire(tire3Year, tire3Pressure);
            Tire tireFour = new Tire(tire4Year, tire4Pressure);

            Tire[] carTires = new Tire[4]
            {
                tireOne,
                tireTwo,
                tireThree,
                tireFour
            };

            tiresList.Add(carTires);

            command = Console.ReadLine()!;
        }

        List<Engine> engineList = new();

        command = Console.ReadLine()!;
        while (command != "Engines done")
        {
            string[] engineSpecs = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            engineList.Add(new Engine(int.Parse(engineSpecs[0]), double.Parse(engineSpecs[1])));

            command = Console.ReadLine()!;
        }

        List<Car> cars = new();

        command = Console.ReadLine()!;
        while (command != "Show special")
        {
            string[] carSpecs = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);

            string make = carSpecs[0];
            string model = carSpecs[1];
            int year = int.Parse(carSpecs[2]);
            double fuelQuantity = double.Parse(carSpecs[3]);
            double fuelConsumption = double.Parse(carSpecs[4]);
            Engine engine = engineList[int.Parse(carSpecs[5])];
            Tire[] tires = tiresList[int.Parse(carSpecs[6])];

            cars.Add(new Car(make, model, year, fuelQuantity, fuelConsumption, engine, tires));

            command = Console.ReadLine()!;
        }

        foreach (Car car in cars) car.PrintIfSpecial();
    }
}